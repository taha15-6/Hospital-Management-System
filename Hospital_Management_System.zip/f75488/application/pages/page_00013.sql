prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>38366036735583739798
,p_default_application_id=>75488
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SYEDUMAIR'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Hospital Diagnosis List'
,p_alias=>'HOSPITAL-DIAGNOSIS-LIST'
,p_step_title=>'Hospital Diagnosis List'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41048114027650197598)
,p_plug_name=>'Hospital Diagnosis List'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'HOSPITALDIAGNOSISLIST'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Hospital Diagnosis List'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(41048114139179197598)
,p_name=>'Hospital Diagnosis List'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'DIAGNOSISTEST_ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:RP:P14_DIAGNOSISTEST_ID:\#DIAGNOSISTEST_ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'HASHMI4603016@CLOUD.NEDUET.EDU.PK'
,p_internal_uid=>41048114139179197598
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41048114884902197599)
,p_db_column_name=>'DIAGNOSISTEST_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Diagnosistest ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41048115243328197599)
,p_db_column_name=>'DEPARTMENT_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Department'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_imp.id(40982597149907049246)
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41048115695595197599)
,p_db_column_name=>'LAB_ADDRESS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Lab Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41048116031517197600)
,p_db_column_name=>'LAB_MOBILE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Lab Mobile'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41048116493759197600)
,p_db_column_name=>'LAB_EMAIL'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Lab Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41048116851377197600)
,p_db_column_name=>'NOTE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Note'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(41049497986836234819)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'410494980'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DIAGNOSISTEST_ID:DEPARTMENT_ID:LAB_ADDRESS:LAB_MOBILE:LAB_EMAIL:NOTE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41048118929866197602)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38555028234616438106)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41048117324805197601)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(41048114027650197598)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:14::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41048117623699197601)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(41048114027650197598)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41048118155082197601)
,p_event_id=>wwv_flow_imp.id(41048117623699197601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41048114027650197598)
);
wwv_flow_imp.component_end;
end;
/
