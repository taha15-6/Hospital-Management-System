prompt --application/shared_components/user_interface/lovs/patient_first_name
begin
--   Manifest
--     PATIENT.FIRST_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>38366036735583739798
,p_default_application_id=>75488
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SYEDUMAIR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38558872680202511896)
,p_lov_name=>'PATIENT.FIRST_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'PATIENT'
,p_return_column_name=>'PATIENT_ID'
,p_display_column_name=>'PATIENT_ID'
,p_icon_column_name=>'FIRST_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'PATIENT_ID'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15622481998105
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(38564338014431317900)
,p_query_column_name=>'PATIENT_ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(38564338437905317901)
,p_query_column_name=>'FIRST_NAME'
,p_heading=>'First Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
