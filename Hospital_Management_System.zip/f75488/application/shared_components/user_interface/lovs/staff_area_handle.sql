prompt --application/shared_components/user_interface/lovs/staff_area_handle
begin
--   Manifest
--     STAFF.AREA_HANDLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>38366036735583739798
,p_default_application_id=>75488
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SYEDUMAIR'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38558874826896511899)
,p_lov_name=>'STAFF.AREA_HANDLE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'STAFF'
,p_return_column_name=>'STAFF_ID'
,p_display_column_name=>'AREA_HANDLE'
,p_default_sort_column_name=>'AREA_HANDLE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15622480571786
);
wwv_flow_imp.component_end;
end;
/
